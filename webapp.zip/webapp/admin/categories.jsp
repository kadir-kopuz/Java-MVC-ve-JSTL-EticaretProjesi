<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kategori Yönetimi - Yönetici Paneli</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-container { display: flex; margin: 20px; gap: 20px; }
        .admin-sidebar { width: 20%; background: #2c3e50; padding: 20px; min-height: 80vh; border-radius: 8px; }
        .admin-sidebar a { display: block; color: #ecf0f1; text-decoration: none; padding: 12px; margin-bottom: 5px; border-radius: 4px; font-weight: 600; }
        .admin-sidebar a:hover { background: #34495e; color: #3498db; }
        .admin-main { width: 80%; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .data-table th, .data-table td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        .data-table th { background-color: #f8f9fa; color: #2c3e50; }
        .badge { padding: 3px 8px; border-radius: 4px; font-size: 11px; color: white; font-weight: bold; }
        .btn-sm { width: auto; padding: 5px 10px; font-size: 12px; display: inline-block; text-decoration: none; margin-right: 5px; }
    </style>
</head>
<body>

    <div class="navbar" style="background-color: #34495e;">
        <a href="dashboard" class="logo">Yönetici Paneli</a>
        <div>
            <a href="../logout" style="color: #e74c3c;">Güvenli Çıkış</a>
        </div>
    </div>

    <div class="admin-container">
        <div class="admin-sidebar">
            <a href="dashboard">Panel Ana Sayfa</a>
            <a href="categories" style="background: #34495e; color: #3498db;">Kategori Yönetimi</a>
            <a href="products">Ürün Yönetimi</a>
            <a href="orders">Sipariş Yönetimi</a>
            <a href="users">Kullanıcı Listesi</a>
        </div>

        <div class="admin-main">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h2>Kategori Yönetimi</h2>
                <a href="category-form" class="btn" style="width: auto; padding: 8px 15px;">+ Yeni Kategori Ekle</a>
            </div>

            <c:if test="${not empty infoMessage}">
                <div class="error-msg" style="background: #ecf0f1; color: #2c3e50; border-color: #bdc3c7;">${infoMessage}</div>
            </c:if>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kategori Adı</th>
                        <th>Açıklama</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="cat" items="${categories}">
                        <tr>
                            <td>${cat.id}</td>
                            <td><strong>${cat.name}</strong></td>
                            <td>${cat.description}</td>
                            <td>
                                <c:choose>
                                    <c:when test="${cat.isActive()}">
                                        <span class="badge" style="background: #2ecc71;">Aktif</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="badge" style="background: #e74c3c;">Pasif</span>
                                    </c:otherwise>
                                </c:choose>
                            </td>
                            <td>
                                <a href="category-form?id=${cat.id}" class="btn btn-sm" style="background: #f39c12;">Düzenle</a>
                                <a href="categories?action=delete&id=${cat.id}" class="btn btn-sm" style="background: #e74c3c;" onclick="return confirm('Bu kategoriyi silmek/pasif yapmak istediğinize emin misiniz?');">Sil</a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>