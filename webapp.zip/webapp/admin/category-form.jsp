<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kategori Formu - Yönetici Paneli</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>

    <div class="navbar" style="background-color: #34495e;">
        <a href="dashboard" class="logo">Yönetici Paneli</a>
    </div>

    <div class="form-container" style="max-width: 600px; margin: 40px auto;">
        <h2><c:choose><c:when test="${not empty category}">Kategori Güncelle</c:when><c:otherwise>Yeni Kategori Ekle</c:otherwise></c:choose></h2>
        
        <c:if test="${not empty errorMessage}">
            <div class="error-msg">${errorMessage}</div>
        </c:if>

        <form action="categories" method="POST">
            <input type="hidden" name="id" value="${category.id}">

            <div class="form-group">
                <label>Kategori Adı <span style="color:red;">*</span></label>
                <input type="text" name="name" value="${category.name}" required placeholder="Örn: Telefon">
            </div>

            <div class="form-group">
                <label>Açıklama</label>
                <textarea name="description" rows="4" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;" placeholder="Kategori kısa açıklaması...">${category.description}</textarea>
            </div>

            <div class="form-group">
                <label>Durum</label>
                <select name="isActive" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                    <option value="true" ${category.isActive() ? 'selected' : ''}>Aktif</option>
                    <option value="false" ${category.id != null && !category.isActive() ? 'selected' : ''}>Pasif</option>
                </select>
            </div>

            <button type="submit" class="btn">Kaydet</button>
            <a href="categories" style="display:block; text-align:center; margin-top:15px; color:#7f8c8d; text-decoration:none;">Vazgeç ve Listeye Dön</a>
        </form>
    </div>

</body>
</html>