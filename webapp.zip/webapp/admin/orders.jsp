<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/libs/jsp/fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sipariş Yönetimi - Yönetici Paneli</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-container { display: flex; margin: 20px; gap: 20px; }
        .admin-sidebar { width: 20%; background: #2c3e50; padding: 20px; min-height: 80vh; border-radius: 8px; }
        .admin-sidebar a { display: block; color: #ecf0f1; text-decoration: none; padding: 12px; margin-bottom: 5px; border-radius: 4px; font-weight: 600; }
        .admin-sidebar a:hover { background: #34495e; color: #3498db; }
        .admin-main { width: 80%; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .data-table th, .data-table td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        .data-table th { background-color: #f8f9fa; color: #2c3e50; }
        .select-status { padding: 5px; border-radius: 4px; border: 1px solid #ccc; font-size: 13px; }
    </style>
</head>
<body>

    <div class="navbar" style="background-color: #34495e;">
        <a href="dashboard" class="logo">Yönetici Paneli</a>
    </div>

    <div class="admin-container">
        <div class="admin-sidebar">
            <a href="dashboard">Panel Ana Sayfa</a>
            <a href="categories">Kategori Yönetimi</a>
            <a href="products">Ürün Yönetimi</a>
            <a href="orders" style="background: #34495e; color: #3498db;">Sipariş Yönetimi</a>
            <a href="users">Kullanıcı Listesi</a>
        </div>

        <div class="admin-main">
            <h2>Sipariş Yönetimi</h2>
            <p style="color:#777;">Sistemdeki tüm müşteri siparişleri ve durumları aşağıda listelenmiştir.</p>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>Sipariş ID</th>
                        <th>Müşteri Adı</th>
                        <th>Sipariş Tarihi</th>
                        <th>Toplam Tutar</th>
                        <th>Mevcut Durum</th>
                        <th>Durum Güncelle</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="order" items="${orders}">
                        <tr>
                            <td>#ORD-${order.id}</td>
                            <td><strong>${order.customerName}</strong></td>
                            <td><fmt:formatDate value="${order.orderDate}" pattern="dd.MM.yyyy HH:mm" /></td>
                            <td><fmt:formatNumber value="${order.totalAmount}" type="currency" currencySymbol="₺" /></td>
                            <td>
                                <c:choose>
                                    <c:when test="${order.status eq 'Beklemede'}"><span style="color:#f39c12; font-weight:bold;">Beklemede</span></c:when>
                                    <c:when test="${order.status eq 'Hazırlanıyor'}"><span style="color:#3498db; font-weight:bold;">Hazırlanıyor</span></c:when>
                                    <c:when test="${order.status eq 'Kargoya Verildi'}"><span style="color:#9b59b6; font-weight:bold;">Kargoya Verildi</span></c:when>
                                    <c:when test="${order.status eq 'Tamamlandı'}"><span style="color:#2ecc71; font-weight:bold;">Tamamlandı</span></c:when>
                                    <c:otherwise><span style="color:#e74c3c; font-weight:bold;">İptal Edildi</span></c:otherwise>
                                </c:choose>
                            </td>
                            <td>
                                <form action="orders" method="POST" style="display:flex; gap:5px;">
                                    <input type="hidden" name="orderId" value="${order.id}">
                                    <select name="status" class="select-status">
                                        <option value="Beklemede" ${order.status eq 'Beklemede' ? 'selected' : ''}>Beklemede</option>
                                        <option value="Hazırlanıyor" ${order.status eq 'Hazırlanıyor' ? 'selected' : ''}>Hazırlanıyor</option>
                                        <option value="Kargoya Verildi" ${order.status eq 'Kargoya Verildi' ? 'selected' : ''}>Kargoya Verildi</option>
                                        <option value="Tamamlandı" ${order.status eq 'Tamamlandı' ? 'selected' : ''}>Tamamlandı</option>
                                        <option value="İptal Edildi" ${order.status eq 'İptal Edildi' ? 'selected' : ''}>İptal Edildi</option>
                                    </select>
                                    <button type="submit" class="btn" style="width:auto; padding:5px 10px; font-size:12px; background:#2c3e50;">Güncelle</button>
                                </form>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>