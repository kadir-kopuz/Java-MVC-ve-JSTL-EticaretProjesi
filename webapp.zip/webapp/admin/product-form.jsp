<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ürün Formu - Yönetici Paneli</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>

    <div class="navbar" style="background-color: #34495e;">
        <a href="dashboard" class="logo">Yönetici Paneli</a>
    </div>

    <div class="form-container" style="max-width: 650px; margin: 30px auto;">
        <h2><c:choose><c:when test="${not empty product}">Ürünü Düzenle</c:when><c:otherwise>Yeni Ürün Ekle</c:otherwise></c:choose></h2>
        
        <c:if test="${not empty errorMessage}">
            <div class="error-msg">${errorMessage}</div>
        </c:if>

        <form action="products" method="POST">
            <input type="hidden" name="id" value="${product.id}">

            <div class="form-group">
                <label>Ürün Adı <span style="color:red;">*</span></label>
                <input type="text" name="name" value="${product.name}" required placeholder="Örn: iPhone 15">
            </div>

            <div class="form-group">
                <label>Kategori Seçimi <span style="color:red;">*</span></label>
                <select name="categoryId" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                    <option value="0">-- Kategori Seçiniz --</option>
                    <c:forEach var="cat" items="${categories}">
                        <option value="${cat.id}" ${product.categoryId == cat.id ? 'selected' : ''}>${cat.name}</option>
                    </c:forEach>
                </select>
            </div>

            <div class="form-group">
                <label>Fiyat (₺) <span style="color:red;">*</span></label>
                <input type="number" step="0.01" name="price" value="${product.price}" required placeholder="54999.90">
            </div>

            <div class="form-group">
                <label>Stok Miktarı <span style="color:red;">*</span></label>
                <input type="number" name="stock" value="${product.stock}" required placeholder="10">
            </div>

            <div class="form-group">
                <label>Görsel Linki (URL)</label>
                <input type="text" name="imageUrl" value="${product.imageUrl}" placeholder="https://site.com/resim.jpg">
            </div>

            <div class="form-group">
                <label>Ürün Açıklaması</label>
                <textarea name="description" rows="3" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">${product.description}</textarea>
            </div>

            <div class="form-group">
                <label>Durum</label>
                <select name="isActive" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                    <option value="true" ${product.isActive() ? 'selected' : ''}>Aktif (Sitede Görünür)</option>
                    <option value="false" ${product.id != null && !product.isActive() ? 'selected' : ''}>Pasif (Gizli)</option>
                </select>
            </div>

            <button type="submit" class="btn">Ürünü Kaydet</button>
            <a href="products" style="display:block; text-align:center; margin-top:15px; color:#7f8c8d; text-decoration:none;">Vazgeç ve Listeye Dön</a>
        </form>
    </div>

</body>
</html>