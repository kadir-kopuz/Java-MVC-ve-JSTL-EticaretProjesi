<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/libs/jsp/fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ürün Yönetimi - Yönetici Paneli</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-container { display: flex; margin: 20px; gap: 20px; }
        .admin-sidebar { width: 20%; background: #2c3e50; padding: 20px; min-height: 80vh; border-radius: 8px; }
        .admin-sidebar a { display: block; color: #ecf0f1; text-decoration: none; padding: 12px; margin-bottom: 5px; border-radius: 4px; font-weight: 600; }
        .admin-sidebar a:hover { background: #34495e; color: #3498db; }
        .admin-main { width: 80%; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .data-table th, .data-table td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; font-size: 14px; }
        .data-table th { background-color: #f8f9fa; color: #2c3e50; }
        .badge { padding: 3px 8px; border-radius: 4px; font-size: 11px; color: white; font-weight: bold; }
        .btn-sm { width: auto; padding: 5px 10px; font-size: 12px; display: inline-block; text-decoration: none; margin-right: 5px; }
    </style>
</head>
<body>

    <div class="navbar" style="background-color: #34495e;">
        <a href="dashboard" class="logo">Yönetici Paneli</a>
    </div>

    <div class="admin-container">
        <div class="admin-sidebar">
            <a href="dashboard">Panel Ana Sayfa</a>
            <a href="categories">Kategori Yönetimi</a>
            <a href="products" style="background: #34495e; color: #3498db;">Ürün Yönetimi</a>
            <a href="orders">Sipariş Yönetimi</a>
            <a href="users">Kullanıcı Listesi</a>
        </div>

        <div class="admin-main">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h2>Ürün Yönetimi</h2>
                <a href="product-form" class="btn" style="width: auto; padding: 8px 15px;">+ Yeni Ürün Ekle</a>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Görsel</th>
                        <th>Ürün Adı</th>
                        <th>Fiyat</th>
                        <th>Stok</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="p" items="${products}">
                        <tr>
                            <td>${p.id}</td>
                            <td><img src="${empty p.imageUrl ? 'https://via.placeholder.com/50' : p.imageUrl}" width="40" height="40" style="object-fit: cover; border-radius: 4px;"></td>
                            <td><strong>${p.name}</strong></td>
                            <td><fmt:formatNumber value="${p.price}" type="currency" currencySymbol="₺" /></td>
                            <td>
                                <c:choose>
                                    <c:when test="${p.stock == 0}"><span style="color:red; font-weight:bold;">Tükendi</span></c:when>
                                    <c:otherwise>${p.stock} Adet</c:otherwise>
                                </c:choose>
                            </td>
                            <td>
                                <c:choose>
                                    <c:when test="${p.isActive()}"><span class="badge" style="background: #2ecc71;">Aktif</span></c:when>
                                    <c:otherwise><span class="badge" style="background: #e74c3c;">Pasif</span></c:otherwise>
                                </c:choose>
                            </td>
                            <td>
                                <a href="product-form?id=${p.id}" class="btn btn-sm" style="background: #f39c12;">Düzenle</a>
                                <a href="products?action=delete&id=${p.id}" class="btn btn-sm" style="background: #e74c3c;" onclick="return confirm('Bu ürünü kalıcı olarak silmek istediğinize emin misiniz?');">Sil</a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>