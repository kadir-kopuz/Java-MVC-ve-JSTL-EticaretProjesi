<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/libs/jsp/fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kullanıcı Listesi - Yönetici Paneli</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-container { display: flex; margin: 20px; gap: 20px; }
        .admin-sidebar { width: 20%; background: #2c3e50; padding: 20px; min-height: 80vh; border-radius: 8px; }
        .admin-sidebar a { display: block; color: #ecf0f1; text-decoration: none; padding: 12px; margin-bottom: 5px; border-radius: 4px; font-weight: 600; }
        .admin-sidebar a:hover { background: #34495e; color: #3498db; }
        .admin-main { width: 80%; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .data-table th, .data-table td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; font-size: 14px; }
        .data-table th { background-color: #f8f9fa; color: #2c3e50; }
    </style>
</head>
<body>

    <div class="navbar" style="background-color: #34495e;">
        <a href="dashboard" class="logo">Yönetici Paneli</a>
    </div>

    <div class="admin-container">
        <div class="admin-sidebar">
            <a href="dashboard">Panel Ana Sayfa</a>
            <a href="categories">Kategori Yönetimi</a>
            <a href="products">Ürün Yönetimi</a>
            <a href="orders">Sipariş Yönetimi</a>
            <a href="users" style="background: #34495e; color: #3498db;">Kullanıcı Listesi</a>
        </div>

        <div class="admin-main">
            <h2>Kayıtlı Kullanıcılar</h2>
            <p style="color:#777;">Sistemde kayıtlı tüm admin ve müşteri hesapları aşağıda listelenmiştir.</p>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ad Soyad</th>
                        <th>E-posta</th>
                        <th>Telefon</th>
                        <th>Rol</th>
                        <th>Kayıt Tarihi</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="u" items="${users}">
                        <tr>
                            <td>${u.id}</td>
                            <td><strong>${u.fullName}</strong></td>
                            <td>${u.email}</td>
                            <td>${empty u.phone ? '-' : u.phone}</td>
                            <td>
                                <span style="font-weight: bold; color: ${u.role eq 'ADMIN' ? '#e74c3c' : '#2ecc71'};">
                                    ${u.role}
                                </span>
                            </td>
                            <td><fmt:formatDate value="${u.createdAt}" pattern="dd.MM.yyyy HH:mm" /></td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>