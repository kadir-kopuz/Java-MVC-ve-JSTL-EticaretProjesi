<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/libs/jsp/fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sepetim - E-Ticaret Portalı</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        .cart-container { max-width: 1000px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .cart-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .cart-table th, .cart-table td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        .cart-table th { background-color: #f8f9fa; color: #2c3e50; }
        .qty-input { width: 60px; padding: 5px; text-align: center; }
        .cart-summary { margin-top: 20px; text-align: right; font-size: 20px; font-weight: bold; color: #2c3e50; }
        .checkout-actions { margin-top: 20px; display: flex; justify-content: space-between; align-items: center; }
        .btn-danger { background-color: #e74c3c; width: auto; padding: 6px 12px; font-size: 13px; }
        .btn-danger:hover { background-color: #c0392b; }
        .btn-success { background-color: #2ecc71; width: auto; padding: 12px 25px; font-size: 16px; }
        .btn-success:hover { background-color: #27ae60; }
    </style>
</head>
<body>

    <div class="navbar">
        <a href="home" class="logo">E-Ticaret Portalı</a>
        <div>
            <a href="home">Ürünler</a>
            <a href="cart">Sepetim</a>
            <c:choose>
                <c:when test="${not empty currentUser}">
                    <a href="my-orders">Siparişlerim</a>
                    <a href="#" style="font-weight: bold; color: #2ecc71;">${currentUser.fullName}</a>
                    <a href="logout" style="color: #e74c3c;">Çıkış Yap</a>
                </c:when>
                <c:otherwise>
                    <a href="login">Giriş Yap</a>
                    <a href="register">Kayıt Ol</a>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <div class="cart-container">
        <h2>Alışveriş Sepetiniz</h2>

        <c:if test="${not empty errorMessage}">
            <div class="error-msg">${errorMessage}</div>
        </c:if>

        <c:choose>
            <c:when test="${not empty cart}">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Ürün Adı</th>
                            <th>Birim Fiyat</th>
                            <th>Adet</th>
                            <th>Ara Toplam</th>
                            <th>İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="item" items="${cart}">
                            <tr>
                                <td><strong>${item.product.name}</strong></td>
                                <td>
                                    <fmt:formatNumber value="${item.product.price}" type="currency" currencySymbol="₺" />
                                </td>
                                <td>
                                    <form action="cart" method="POST" style="display: flex; gap: 5px; align-items: center;">
                                        <input type="hidden" name="productId" value="${item.product.id}">
                                        <input type="number" name="quantity" class="qty-input" value="${item.getQuantity()}" min="1">
                                        <button type="submit" class="btn" style="width:auto; padding: 5px 10px; font-size: 12px; background:#95a5a6;">Güncelle</button>
                                    </form>
                                </td>
                                <td>
                                    <fmt:formatNumber value="${item.subtotal}" type="currency" currencySymbol="₺" />
                                </td>
                                <td>
                                    <a href="cart?action=remove&id=${item.product.id}" class="btn btn-danger">Çıkar</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>

                <div class="cart-summary">
                    Genel Toplam: <fmt:formatNumber value="${grandTotal}" type="currency" currencySymbol="₺" />
                </div>

                <div class="checkout-actions">
                    <a href="home" style="color: #3498db; text-decoration: none;">← Alışverişe Devam Et</a>
                    <a href="order" class="btn btn-success">Siparişi Tamamla</a>
                </div>
            </c:when>
            <c:otherwise>
                <div style="text-align: center; padding: 40px 0;">
                    <p style="font-size: 18px; color: #777; margin-bottom: 20px;">Sepetinizde henüz ürün bulunmamaktadır.</p>
                    <a href="home" class="btn" style="width: auto; padding: 10px 20px;">Ürünleri İncele</a>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

</body>
</html>