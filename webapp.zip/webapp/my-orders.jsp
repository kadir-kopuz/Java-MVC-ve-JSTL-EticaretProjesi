<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/libs/jsp/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/libs/jsp/fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Siparişlerim - E-Ticaret Portalı</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        .orders-container { max-width: 950px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .orders-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .orders-table th, .orders-table td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        .orders-table th { background-color: #f8f9fa; color: #2c3e50; }
        .status-badge { padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; color: white; display: inline-block; }
    </style>
</head>
<body>

    <div class="navbar">
        <a href="home" class="logo">E-Ticaret Portalı</a>
        <div>
            <a href="home">Ürünler</a>
            <a href="cart">Sepetim</a>
            <a href="my-orders">Siparişlerim</a>
            <a href="#" style="font-weight: bold; color: #2ecc71;">${currentUser.fullName}</a>
            <a href="logout" style="color: #e74c3c;">Çıkış Yap</a>
        </div>
    </div>

    <div class="orders-container">
        <h2>Sipariş Geçmişiniz</h2>

        <c:if test="${not empty successMessage}">
            <div class="error-msg" style="background: #d4edda; color: #155724; border-color: #c3e6cb;">
                ${successMessage}
            </div>
        </c:if>

        <c:choose>
            <c:when test="${not empty orders}">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>Sipariş No</th>
                            <th>Sipariş Tarihi</th>
                            <th>Toplam Tutar</th>
                            <th>Sipariş Durumu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="order" items="${orders}">
                            <tr>
                                <td>#ORD-${order.id}</td>
                                <td>
                                    <fmt:formatDate value="${order.orderDate}" pattern="dd.MM.yyyy HH:mm" />
                                </td>
                                <td>
                                    <fmt:formatNumber value="${order.totalAmount}" type="currency" currencySymbol="₺" />
                                </td>
                                <td>
                                    <c:choose>
                                        <c:when test="${order.status eq 'Beklemede'}">
                                            <span class="status-badge" style="background: #f39c12;">Beklemede</span>
                                        </c:when>
                                        <c:when test="${order.status eq 'Hazırlanıyor'}">
                                            <span class="status-badge" style="background: #3498db;">Hazırlanıyor</span>
                                        </c:when>
                                        <c:when test="${order.status eq 'Kargoya Verildi'}">
                                            <span class="status-badge" style="background: #9b59b6;">Kargoya Verildi</span>
                                        </c:when>
                                        <c:when test="${order.status eq 'Tamamlandı'}">
                                            <span class="status-badge" style="background: #2ecc71;">Tamamlandı</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="status-badge" style="background: #e74c3c;">İptal Edildi</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </c:when>
            <c:otherwise>
                <p style="text-align: center; color:#777; padding: 30px 0;">Henüz verilmiş bir siparişiniz bulunmamaktadır.</p>
            </c:otherwise>
        </c:choose>
    </div>

</body>
</html>